# Adsterra Popunder — Vertical Steps (Animated)

- 6 steps vertically, each with **Open Ad** button.
- Visible **countdown timer** per step after clicking.
- Messages: "Ad opened…", "You came back too early", and "Completed ✓".
- Progress bar + **Get Your Link** unlock button (enabled when all 6 done).
- Animated gradient background (subtle, modern).

## Replace with live codes
- **Popunder**: put your Adsterra popunder script in `assets/js/popunder.js` (replace file).
- **Direct Links**: edit `openAd()` URL in `assets/js/app.js` (you can set different links per task if you add a map).
- **Final URL**: set `CONFIG.finalUrl` in `assets/js/app.js`.

## Deploy
Upload folder to Netlify / Vercel / Cloudflare Pages or any static host.
