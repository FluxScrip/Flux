
// --- Config ---
const CONFIG = {
  minDwellSeconds: 5,
  finalUrl: "https://example.com/linkvertise-placeholder" // TODO: set your Linkvertise URL
};

const TASKS = ["ad1","ad2","ad3","ad4","ad5","ad6"];
const key = "reward_steps_state_v1";
let state = { completed:{}, openTime:{}, popFired:false };
try{ Object.assign(state, JSON.parse(localStorage.getItem(key)||"{}")); }catch{}
function save(){ localStorage.setItem(key, JSON.stringify(state)); }

function fmtBadge(id, ok){
  const el = document.getElementById(id);
  if(!el) return;
  el.textContent = ok ? "Completed" : "Locked";
  el.classList.toggle("unlocked", ok);
  el.classList.toggle("locked", !ok);
}

function updateProgress(){
  let done = 0;
  TASKS.forEach(t => { if(state.completed[t]) done++; });
  const pct = Math.round(done / TASKS.length * 100);
  document.getElementById("bar").style.width = pct + "%";
  document.getElementById("progressText").textContent = `Steps Completed ${done}/${TASKS.length}`;
  const all = done === TASKS.length;
  const btn = document.getElementById("unlockBtn");
  btn.disabled = !all;
}
function refreshUI(){
  TASKS.forEach(t => fmtBadge("status-"+t, !!state.completed[t]));
  updateProgress();
}
refreshUI();

// One-time popunder on first click (placeholder delegated to popunder.js)
document.addEventListener("click", () => {
  if(state.popFired) return;
  state.popFired = true; save();
  if(window.firePopunder) window.firePopunder();
}, { once: true });

// Countdown handling
const timers = {}; // taskId -> interval
function startCountdown(taskId){
  stopCountdown(taskId);
  const target = (state.openTime[taskId] || Date.now()) + CONFIG.minDwellSeconds*1000;
  const el = document.getElementById("timer-"+taskId);
  const status = document.getElementById("msg-"+taskId);
  function tick(){
    const now = Date.now();
    const remain = Math.ceil((target - now)/1000);
    if(remain > 0){
      el.textContent = `Wait ${remain}s`;
      status.textContent = "Ad opened…";
    }else{
      el.textContent = "Ready";
      status.textContent = "Return to this tab to complete";
      clearInterval(timers[taskId]); delete timers[taskId];
    }
  }
  timers[taskId] = setInterval(tick, 200);
  tick();
}
function stopCountdown(taskId){
  if(timers[taskId]){ clearInterval(timers[taskId]); delete timers[taskId]; }
}

// Open ad + start timer
function openAd(taskId){
  const url = "https://example.com/"; // TODO: set your Adsterra Direct Link
  const w = window.open(url, "_blank", "noopener");
  if(!w){
    document.getElementById("msg-"+taskId).textContent = "Popup blocked. Allow popups for this site.";
    return;
  }
  state.openTime[taskId] = Date.now(); save();
  document.getElementById("msg-"+taskId).textContent = "Ad opened… stay 5s";
  startCountdown(taskId);
}
window.openAd = openAd;

// When user returns to tab, verify all tasks
document.addEventListener("visibilitychange", () => {
  if(document.visibilityState === "visible"){
    TASKS.forEach(verifyTask);
  }
});

function verifyTask(taskId){
  const start = state.openTime[taskId];
  if(!start) return;
  const elapsed = (Date.now() - start)/1000;
  const timerEl = document.getElementById("timer-"+taskId);
  const msgEl = document.getElementById("msg-"+taskId);
  if(elapsed < CONFIG.minDwellSeconds){
    const remain = Math.ceil(CONFIG.minDwellSeconds - elapsed);
    msgEl.textContent = `You came back too early. Wait ${remain}s more.`;
    startCountdown(taskId);
    return;
  }
  state.completed[taskId] = true; save();
  stopCountdown(taskId);
  timerEl.textContent = "";
  msgEl.textContent = "Completed ✓";
  fmtBadge("status-"+taskId, true);
  updateProgress();
}

function goToFinal(){ window.location.href = CONFIG.finalUrl; }
window.goToFinal = goToFinal;
