
// Placeholder popunder for testing only.
// Replace with your real Adsterra popunder script when live.
window.firePopunder = function(){
  try{
    window.open("https://example.com/", "_blank", "noopener");
    console.log("Popunder placeholder fired. Insert Adsterra code in assets/js/popunder.js");
  }catch(e){
    console.warn("Popunder blocked:", e);
  }
};
